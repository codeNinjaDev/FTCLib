package org.firstinspires.ftc.ftccommon.external;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.qualcomm.robotcore.robot.RobotState;
import com.qualcomm.robotcore.robot.RobotStatus;

import org.firstinspires.ftc.robotcore.internal.network.NetworkStatus;
import org.firstinspires.ftc.robotcore.internal.network.PeerStatus;

public class SoundPlayingRobotMonitor implements RobotStateMonitor {
    @Override
    public void updateRobotState(@NonNull RobotState robotState) {

    }

    @Override
    public void updateRobotStatus(@NonNull RobotStatus robotStatus) {

    }

    @Override
    public void updatePeerStatus(@NonNull PeerStatus peerStatus) {

    }

    @Override
    public void updateNetworkStatus(@NonNull NetworkStatus networkStatus, @Nullable String extra) {

    }

    @Override
    public void updateErrorMessage(@Nullable String errorMessage) {

    }

    @Override
    public void updateWarningMessage(@Nullable String warningMessage) {

    }
}
