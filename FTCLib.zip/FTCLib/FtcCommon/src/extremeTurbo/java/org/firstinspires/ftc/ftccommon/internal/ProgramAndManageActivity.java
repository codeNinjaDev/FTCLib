package org.firstinspires.ftc.ftccommon.internal;

import org.firstinspires.ftc.robotcore.internal.ui.ThemedActivity;

public class ProgramAndManageActivity extends ThemedActivity
{
    @Override
    public String getTag()
    {
        return "";
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture)
    {

    }
}
